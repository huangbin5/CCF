// INFO BEGIN
//
// User = 201910012657(�Ʊ�) 
// Group = C/C++ 
// Problem = �ַ��� 
// Language = CPP11 
// SubmitTime = 2019-09-15 15:40:56 
//
// INFO END

#include <iostream>
#include <cstdio>
#include <cstring>
typedef long long ll;
using namespace std;
//#define DEBUG

const int maxn=1100;
const int maxm=2000;
int n,m,p,q;
char s[10];
struct Color{
    int r,g,b;
}color[maxn][maxm];
int pr=0,pg=0,pb=0;

int to_dec(char c){
    if(c>='0'&&c<='9')
        return c-'0';
    return c-'a'+10;
}

void input(int i,int j){
    int len=strlen(s);
    if(len==7){
        color[i][j].r=(to_dec(s[1])*16+to_dec(s[2]));
        color[i][j].g=(to_dec(s[3])*16+to_dec(s[4]));
        color[i][j].b=(to_dec(s[5])*16+to_dec(s[6]));
    }else if(len==4){
        color[i][j].r=(to_dec(s[1])*16+to_dec(s[1]));
        color[i][j].g=(to_dec(s[2])*16+to_dec(s[2]));
        color[i][j].b=(to_dec(s[3])*16+to_dec(s[3]));
    }else{
        color[i][j].r=(to_dec(s[1])*16+to_dec(s[1]));
        color[i][j].g=(to_dec(s[1])*16+to_dec(s[1]));
        color[i][j].b=(to_dec(s[1])*16+to_dec(s[1]));
    }
}

void printInt(int a){
    if(a>100){
        printf("\\x%X",a/100+'0');
        a%=100;
    }
    if(a>10){
        printf("\\x%X",a/10+'0');
        a%=10;
    }
    printf("\\x%X",a+'0');
}

void setColor(int r,int g,int b){
    printf("\\x1B\\x5B\\x34\\x38\\x3B\\x32\\x3B");
    printInt(r);
    printf("\\x3B");
    printInt(g);
    printf("\\x3B");
    printInt(b);
    printf("\\x6D");
}

void setDefault(){
    printf("\\x1B\\x5B\\x30\\x6D");
}

void printBlank(){
    printf("\\x20");
}

void printLine(){
    printf("\\x0A");
}

int main(){
#ifdef DEBUG
    freopen("d:\\my\\in.txt","r",stdin);
    freopen("d:\\my\\out.txt","w",stdout);
#endif // DEBUG
    scanf("%d%d%d%d",&m,&n,&p,&q);
    for(int i=0;i<n;++i){
        for(int j=0;j<m;++j){
            scanf("%s",s);
            input(i,j);
        }
    }
    for(int i=0;i<n/q;++i){
        for(int j=0;j<m/p;++j){
            int r=0,g=0,b=0;
            for(int x=i*q;x<i*q+q;++x){
                for(int y=j*p;y<j*p+p;++y){
                    r+=color[x][y].r;
                    g+=color[x][y].g;
                    b+=color[x][y].b;
                }
            }
            r/=(p*q);
            g/=(p*q);
            b/=(p*q);
            if(r!=pr||g!=pg||b!=pb){
                if(r==0&&g==0&&b==0)
                    setDefault();
                else
                    setColor(r,g,b);
                pr=r;
                pg=g;
                pb=b;
            }
            printBlank();
        }
        if(pr!=0||pg!=0||pb!=0){
            setDefault();
            pr=0;
            pg=0;
            pb=0;
        }
        printLine();
    }
    return 0;
}
