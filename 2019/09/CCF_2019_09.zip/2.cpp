// INFO BEGIN
//
// User = 201910012657(�Ʊ�) 
// Group = C/C++ 
// Problem = С����ƻ�������� 
// Language = CPP11 
// SubmitTime = 2019-09-15 14:10:07 
//
// INFO END

#include <iostream>
#include <cstdio>
typedef long long ll;
using namespace std;
//#define DEBUG

const int maxn=1005;
int sum[maxn]={0};
bool isFall[maxn]={false};
int n,sumAns=0,fallAns=0,pairAns=0;

int main(){
#ifdef DEBUG
    freopen("d:\\my\\in.txt","r",stdin);
    freopen("d:\\my\\out.txt","w",stdout);
#endif // DEBUG
    scanf("%d",&n);
    int m,a;
    for(int i=1;i<=n;++i){
        scanf("%d",&m);
        for(int j=0;j<m;++j){
            scanf("%d",&a);
            //ͳ������
            if(a>0){
                if(sum[i]>a){
                    isFall[i]=true;
                }
                sum[i]=a;
            }else{
                //�߹�
                sum[i]+=a;
            }
        }
        sumAns+=sum[i];
    }
    for(int i=1;i<=n;++i){
        if(isFall[i]){
            ++fallAns;
            if(isFall[i%n+1]&&isFall[(i+1)%n+1])
                ++pairAns;
        }
    }
    printf("%d %d %d",sumAns,fallAns,pairAns);
    return 0;
}
