// INFO BEGIN
//
// User = 201910012657(�Ʊ�) 
// Group = C/C++ 
// Problem = ���й滮 
// Language = CPP11 
// SubmitTime = 2019-09-15 17:29:45 
//
// INFO END

#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
typedef long long ll;
using namespace std;
//#define DEBUG

const int maxn=2005;
const int INF=0x3fffffff;
int G[maxn][maxn]={0},imp[maxn],dis[maxn][maxn];
int m,n,k;
vector<int> sel;
ll ans=-1;

void floyd(){
    fill(dis[0],dis[0]+n*n,INF);
    for(int k=0;k<n;++k)
        for(int i=0;i<n;++i)
            for(int j=0;j<n;++j)
                if(dis[i][k]!=INF&&dis[k][j]!=INF&&dis[i][k]+dis[k][j]<dis[i][j])
                    dis[i][j]=dis[i][k]+dis[k][j];
}

void cacul(){
    ll ret=0;
    for(int i=0;i<sel.size();++i)
        for(int j=i+1;j<sel.size();++j)
            ret+=dis[i][j];
    if(ans==-1||ret<ans)
        ans=ret;
}

void dfs(int x){
    if(sel.size()==k){
        cacul();
        return;
    }
    sel.push_back(imp[x]);
    for(int i=x+1;i<m;++i)
        dfs(i);
    sel.pop_back();
}

int main(){
#ifdef DEBUG
    freopen("d:\\my\\in.txt","r",stdin);
    freopen("d:\\my\\out.txt","w",stdout);
#endif // DEBUG
    scanf("%d%d%d",&n,&m,&k);
    for(int i=0;i<m;++i)
        scanf("%d",&imp[i]);
    int u,v,d;
    for(int i=0;i<n-1;++i){
        scanf("%d%d%d",&u,&v,&d);
        G[u][v]=G[v][u]=d;
    }
    floyd();
    sel.clear();
    dfs(0);
    printf("%lld",ans);
    return 0;
}
