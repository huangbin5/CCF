// INFO BEGIN
//
// User = 201910012657(�Ʊ�) 
// Group = C/C++ 
// Problem = �Ƽ�ϵͳ 
// Language = CPP11 
// SubmitTime = 2019-09-15 16:59:35 
//
// INFO END

#include <iostream>
#include <cstdio>
#include <vector>
#include <map>
#include <algorithm>
typedef long long ll;
using namespace std;
//#define DEBUG

struct Commodity{
    int brandId,id,score,del;
    Commodity(){}
    Commodity(int _brandId,int _id,int _score,int _del):brandId(_brandId),id(_id),score(_score),del(_del){}
};
map<int,Commodity> brand[50];
vector<Commodity*> commodities;
int m,n;

bool cmp(Commodity *a,Commodity *b){
    if(a->del!=b->del)
        return a->del<b->del;
    if(a->score!=b->score)
        return a->score>b->score;
    if(a->brandId!=b->brandId)
        return a->brandId<b->brandId;
    return a->id<b->id;
}

int main(){
#ifdef DEBUG
    freopen("d:\\my\\in.txt","r",stdin);
    freopen("d:\\my\\out.txt","w",stdout);
#endif // DEBUG
    scanf("%d%d",&m,&n);
    int id,score;
    for(int i=0;i<n;++i){
        scanf("%d%d",&id,&score);
        for(int j=0;j<m;++j){
            brand[j][id]=Commodity(j,id,score,0);
            commodities.push_back(&(brand[j][id]));
        }
    }
    int qNum,qType,brandId,qSelect;
    scanf("%d",&qNum);
    for(int i=0;i<qNum;++i){
        scanf("%d",&qType);
        if(qType==1){
            scanf("%d%d%d",&brandId,&id,&score);
            if(brand[brandId].count(id)){
                brand[brandId][id].score=score;
                brand[brandId][id].del=0;
            }else{
                brand[brandId][id]=Commodity(brandId,id,score,0);
                commodities.push_back(&(brand[brandId][id]));
            }
        }else if(qType==2){
            scanf("%d%d",&brandId,&id);
            brand[brandId][id].del=1;
        }else{
            int limit[50],selectedNum=0;
            vector<int> selected[50];
            scanf("%d",&qSelect);
            for(int j=0;j<m;++j)
                scanf("%d",&limit[j]);
            sort(commodities.begin(),commodities.end(),cmp);
            for(int j=0;j<commodities.size();++j){
                Commodity *tmp=commodities[j];
                if(tmp->del==1)
                    break;
                if(selected[tmp->brandId].size()<limit[tmp->brandId]){
                    selected[tmp->brandId].push_back(tmp->id);
                    ++selectedNum;
                    if(selectedNum>=qSelect)
                        break;
                }
            }
            for(int j=0;j<m;++j){
                if(selected[j].empty())
                    printf("-1\n");
                else{
                    for(int k=0;k<selected[j].size();++k){
                        if(k==selected[j].size()-1)
                            printf("%d\n",selected[j][k]);
                        else
                            printf("%d ",selected[j][k]);
                    }
                }
            }
        }
    }
    return 0;
}
